#!/usr/bin/php
<?php

  $real = glob('/Volumes/*');

  function execute($cmd) {
    $part = popen('sudo '.$cmd.' 2>&1', 'r');
    $value = '';
    while (($data = fread($part, 128)) != false) {
      $value .= $data;
    }
    pclose($part);
    return $value;
  }
  function listDisks() {
    $ptr = -1;
    $list = [];

    $value = explode("\n", execute('diskutil list'));
    $sections = [];
    $disable_action = false;

    foreach ($value as $line) {
      $line = trim($line);

      if ($line == null) continue;

      switch (mb_substr($line, 0, 1)) {
        case '/':
          if (mb_strpos(mb_strtolower($line), 'physical') === false) {
            $disable_action = true;
            break;
          }
          $disable_action = false;
          $z = explode(" ", $line);
          $ptr++;
          $list[$ptr] = [
            'device'=> $z[0],
            'type'=> false,
            'size'=> '',
            'volumes'=> []
          ]; 
          break;
        case '#':
          if ($disable_action) break;

          $sect = 0;
          $sections = [
            0=> 0
          ];

          $before = null;
          for ($i = 0; $i < mb_strlen($line); $i++) {
            if ($sect < 2) {
              if ($before != null && $before != ' ' && $line[$i] == ' ') {
                $sections[] = $i + 1;
                $sect++;
              }
            } else {
              if ($before == ' ' && $line[$i] != ' ') {
                if (!isset($sections[$sect])) {
                  $sections[$sect] = $i;
                } 
                $sect++;
              }
            }
            $before = $line[$i];
          }
          break;
        case '0':
          if ($disable_action) break;

          $type = trim(mb_substr($line, $sections[1], $sections[2] - $sections[1]));
          switch (mb_strtoupper(mb_substr($type, 0, 4))) {
            case 'GUID':
              $list[$ptr]['type'] = 'GPT';
              break;
            case 'APFS':
              $list[$ptr]['type'] = 'APFS';
              break;
            case 'FDIS':
              $list[$ptr]['type'] = 'MBR';
              break;
            default:
              $list[$ptr]['type'] = 'OTHER';
          }
          $list[$ptr]['size'] = trim(mb_substr($line, $sections[3], $sections[4] - $sections[3]));
          break;
        case " ":
        case "\t":
          break;
        default:
          if ($disable_action) break;

          $list[$ptr]['volumes'][] = [
            'type'=>   trim(mb_substr($line, $sections[1], $sections[2] - $sections[1])),
            'name'=>   trim(mb_substr($line, $sections[2], $sections[3] - $sections[2])),
            'size'=>   trim(mb_substr($line, $sections[3], $sections[4] - $sections[3])),
            'device'=> trim(mb_substr($line, $sections[4]))
          ];
          break;
      }
    }
    return $list;
  }

  function getDeviceInfo($dev) {
    $list = [];
    $value = explode("\n", execute('diskutil info ' . $dev));
    foreach ($value as $line) {
      if (trim($line) == null) continue;

      $line = explode(':', $line);

      $key = mb_strtolower(trim(array_shift($line)));
      $value = trim(implode(':', $line));

      if (trim($key) == null || trim($value) == null) continue;

      $key = str_replace([
        '/',  ' ', '-', '(',  ')'
      ], [
        null, '_', '_', null, null
      ], $key);

      $list[mb_strtolower($key)] = $value;
    }
    return $list;
  }

  function isOCDevice($root) {
    return file_exists($root . '/EFI/OC/OpenCore.efi');
  }

  $flag = false;
  foreach(listDisks() as $disk) {
    if ($flag) {
      return;
    }
    $par = explode("/", $disk['device']);

    foreach ($disk['volumes'] as $volume) {
      if ($volume['type'] == 'EFI') {
        $par[count($par)-1] = $volume['device'];
        
        $efi_test = implode("/", $par);

        $info = getDeviceInfo($efi_test);
        
        if ($info['mounted'] == 'Yes') {
          if (isOCDevice($info['mount_point'])) {
            echo 'OpenCore EFI was mounted before: [ '.$info['mount_point'].' ]!'.PHP_EOL;
            $flag = true;
          }
        } else {
          execute('diskutil mount ' . $efi_test);
          $info = getDeviceInfo($efi_test);

          if ($info['mounted'] != 'Yes') {
            echo 'Can\'t mount device '.$efi_test.': permission denied!'.PHP_EOL;
          } else {
            if (isOCDevice($info['mount_point'])) {
              echo 'OpenCore EFI mounted now: [ '.$info['mount_point'].' ]!'.PHP_EOL;
              $flag = true;
            } else {
              execute('diskutil unmount ' . $efi_test);
            }
          }
        }
      }
    }
  }
  if (!$flag) {
    echo 'OpenCore EFI can\'t be found (or can\'t be mounted)...'.PHP_EOL;
  }
  echo PHP_EOL;
