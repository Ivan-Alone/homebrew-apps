#!/bin/bash
sudo php "$(dirname $0)/efi.php"
